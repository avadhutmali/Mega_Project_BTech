@echo off
REM ============================================================
REM  IdleGrid Agent — Windows launcher (pre-built distribution)
REM  Simply run this file. No build step needed.
REM
REM  To change the Master URL, edit agent.properties in this
REM  same folder before running.
REM ============================================================

set JAR=agent-1.0-SNAPSHOT-exec.jar

if not exist "%JAR%" (
    echo [ERROR] JAR not found: %JAR%
    echo Make sure you are running this bat file from inside the IdleGridAgent folder.
    exit /b 1
)

echo Starting IdleGrid Agent...
echo JAR:     %CD%\%JAR%
echo Config:  %CD%\agent.properties  (edit this to set master.url)
echo Logs:    %CD%\logs\
echo.

java -jar "%JAR%" %*
