IdleGrid PyTorch DDP image demo bundle

Contents: train.py and 90 small generated PNGs (30 each of circle, square, triangle).
The generated images are a quick smoke-test dataset, not real-world training data.

In the dashboard choose this ZIP and submit:
  train.py --epochs 2 --batch-size 32
Use 2 or 3 workers. The script uses DistributedSampler and CPU/Gloo DDP; rank 0
saves model.pt, which the dashboard makes available when the run finishes.

Each worker downloads the same ZIP. The sampler assigns each rank its own sample
subset; gradient synchronization happens during training. Every selected PC must
have the IdleGrid PyTorch CPU image built and Docker host networking enabled.
