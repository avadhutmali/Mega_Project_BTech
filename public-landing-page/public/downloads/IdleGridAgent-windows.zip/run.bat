@echo off
REM ============================================================
REM  IdleGrid Agent — Windows launcher (pre-built distribution)
REM
REM  FIRST TIME? Run setup.ps1 as Administrator first:
REM    Right-click setup.ps1 → "Run with PowerShell" (as Admin)
REM
REM  Then edit agent.properties to set your master.url, and run:
REM    run.bat
REM ============================================================

set JAR=agent-1.0-SNAPSHOT-exec.jar

if not exist "%JAR%" (
    echo [ERROR] JAR not found: %JAR%
    echo Make sure you are running this bat file from inside the IdleGridAgent folder.
    exit /b 1
)

echo Starting IdleGrid Agent...
echo JAR:     %CD%\%JAR%
echo Config:  %CD%\agent.properties  (edit this to set master.url)
echo Logs:    %CD%\logs\
echo.

java -jar "%JAR%" %*
